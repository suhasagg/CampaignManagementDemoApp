'use strict';
var forms = angular.module('Forms',['formly']);