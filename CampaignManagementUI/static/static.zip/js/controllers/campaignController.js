"use strict";
var cubeRootApp = angular.module('CubeRootApp');
cubeRootApp.controller('campaignCtrl',['$scope','commonService',function($scope,commonService){

}]);

